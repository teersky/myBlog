# =============================================================================================================
# English:

Requirements:
- CCSM must be installed
- Graphics Card must support "GL_ARB_fragment_program" API or Blur and Reflect features wont work

Features:
- Blur
- Reflection

To install the Win2-7_CCSM.profile follow these steps:
1. Press and hold Alt and tap F2 then release
2. Type: "ccsm" and press enter
3. Click on "Preferences"
4. Under "Profile" click "Import"
5. Browse to the Desktop and select "Win2-7_CCSM.profile"
6. Wait a few moments for changes to take effect
7. Go back to the CCSM main page
8. Enable Blur and/or Reflection useing the checkbox if they are not already enabled/checked
9. Delete this CompizReadMe.txt and Win2-7_CCSM.profile off the desktop

Done! :D

# =============================================================================================================
# French:

Pré-requis :
- CCSM doit être installé
- Votre carte graphique doit supporter l'API "GL_ARB_fragment_program" sinon les effets de flou et de réflexion ne fonctionneront pas.

Caractéristiques :
- Flou
- Réflection

Pour installer le Profil Win2-7_CCSM.profile suivez ces étapes :
1. Pressez et maintenez la touche <Alt> du clavier puis pressez <F2>. Relâchez ensuite les deux touches.
2. Tapez : "ccsm" et presez la touche <Entrée>.
3. Cliquez sur "Préferences".
4. Dans "Profil" cliquez sur "Importer".
5. Utilisez le sélecteur de fichiers pour sélectionner "Win2-7_CCSM.profile" qui se trouve sur le bureau.
6. Attendez quelques secondes pour que les changements prennent effet.
7. Retournez sur la page principale de CCSM.
8. Activez les fonctions de Flou et/ou réflexion en cochant les cases adéquates si elles ne le sont pas déjà.
9. Effacez ce fichier CompizReadMe.txt et le profil Win2-7_CCSM.profile du bureau.

Voilà, c'est fait ! :D

=============================================================================================================
# Spanish:

Requisitos:
- CCSM
- Tarjeta gráfica debe soportar "GL_ARB_fragment_program" API o las características de desenfoque y reflejo no funcionarán.

Características:
- Desenfoque
- Reflejo

Para instalar el win2-7_CCSM.profile sigue estos pasos:
1. Pulsa y manten pulsado Alt y pulsa F2 luego suelta ambas teclas
2. Introduce: "ccsm" y oprime enter
3. Haz clic en "Preferencias"
4. En la sección "Perfil", haz clic en "Importar"
5. Navega hasta el escritorio y selecciona "win2-7_CCSM.profile"
6. Espera unos minutos para que los cambios surtan efecto
7. Vuelve a la página principal CCSM
8. Habilita desenfoque y/o reflejos mediante la casilla de verificación si no han sido habilitados aún
9. Eliminar este CompizReadMe.txt y win2 7_CCSM.profile del escritorio

¡Listo! :D

=============================================================================================================
# Portuguese:

Requisitos:
- CCSM deve está instalado
- A placa gráfica tem que suportar "GL_ARB_fragment_program" API e Blur ou as características reflexão não vão funcionar

Características:
- Blur
- Reflexão

Para instalar o WIN2-7_CCSM.profile siga estes passos:
1. Pressione e segure a tecla Alt e pressione F2 e solte
2. Digite: "ccsm" e pressione enter
3. Clique em "Preferências"
4. Em "Perfil", clique em "Importar"
5. Vá para o Desktop e selecione "WIN2-7_CCSM.profile"
6. Aguarde alguns instantes para que as alterações entrem em vigor
7. Volte à página principal CCSM
8. Habilite o Blur e/ou reflexão utilizando a caixa se eles não estiverem ativados/verificados
9. Excluir este CompizReadMe.txt e WIN2-7_CCSM.profile do desktop

Feito!:D

# =============================================================================================================
# Croatian:

Zahtjevi:
- CCSM mora biti instaliran
- Grafička kartica mora podržavati "GL_ARB_fragment_program" API ili Blur i Reflect dodatci neće raditi

Dodatci:
- Blur
- Reflection

Da biste instalirali Win2-7_CCSM.profile slijedite ove upute:
1. Pritisnite i držite Alt te pritisnite F2 i pustite obe tipke
2. Upišite: "ccsm" i pritisnite Enter
3. Kliknite na "Postavke"
4. Pod "Profile & Backend" kliknite na "Uvesti"
5. Dođite do Radne površine i odaberite "Win2-7_CCSM.profile"
6. Pričekajte nekoliko trenutaka da se učitaju promjene
7. Vratite se na CCSM-ovu početnu stranicu
8. Uključite Blur i/ili Reflection tako da dobijete kvačicu ako je već uključeno
9. Obrišite ovu CompizReadMe.txt datoteku i Win2-7_CCSM.profile sa Radne površine

Gotovo! :D

