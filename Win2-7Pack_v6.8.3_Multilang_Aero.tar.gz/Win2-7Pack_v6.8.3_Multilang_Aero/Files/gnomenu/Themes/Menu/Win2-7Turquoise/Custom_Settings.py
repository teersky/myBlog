#!/usr/bin/env python
#=========================
# Settings Pane for theme
# By QB89Dragon 2008
#=========================

class InsertPane():
	def __init__(self, frame):
		button = gtk.Button()
	
