# =============================================================================================================
# English:

Directions:
These switches are for Advanced Users only and should only be used if you know what you are doing or are requested to do so. Just double click on the icon and use "Run In Terminal". Use at your own Risk!

==== GUIInstall.sh Switches:  ====

"--errordump" switch is to generate a error file to give information about your system to help debug a issue with the script if the script is unable to generate a error dump on its own. You may be asked to post this information for troubleshooting purposes.

"--language" switch is to choose what language you want to use to override your current language.

"--reinstallmurrine" switch is used to reinstall the Advanced Murrine Engine in case of a overwrite by a updated version of Murrine from the Update Manager.

"--unholdmurrine" switch is used if you want to unhold the Advanced Murrine Engine.

# =============================================================================================================
# French:

Consignes :
Ces paramètres sont destinés aux utilisateurs avancés et ne devraient être utilisés que si vous maîtrisez ce que vous faites ou bien si cela vous a été suggéré. Double-cliquez simplement sur l'icône et choisissez "Lancer dans un terminal". Utilisez à vos risques et périls.

==== Paramètres de GUIInstall.sh  ====

"--errordump" : ce paramètre permet de générer un fichier de rapport d'erreurs afin de fournir des informations sur votre système susceptibles d'aider au débugage des problèmes rencontrés avec le script si ce dernier ne parvient pas à générer ce fichier par lui-même. On pourra vous demander de nous fournir ces informations pour résoudre vos problèmes.

"--language" : ce paramètre permet d'utiliser le langage de votre choix à la place de celui de votre système.

"--reinstallmurrine" Ce paramètre est utilisé pour réinstaller le moteur avancé de Murrine dans le cas où ce dernier aurait été écrasé par une mise à jour via le gestionnaire de mises à jour.

"--unholdmurrine" : Ce paramètre est utilisé pour reprendre l'installation du moteur avancé de Murrine.

# =============================================================================================================
# Spanish:

Instrucciones:
Estos switches son para usuarios avanzados únicamente y sólo deben utilizarse si sabes lo que estas haciendo o se te haya solicitado hacerlo. Solo haz doble clic en el icono y elije "Ejecutar en terminal". Utilízalo bajo tu propio riesgo!

==== GUIInstall.sh Switches: ====

"--errordump" es para generar un archivo de errores mostrando la información sobre su sistema y así ayudar a depurar un problema con la secuencia de comandos si el script no es capaz de generar un volcado de error por su cuenta. Se te puede pedir para enviar esta información para solucionar problemas.

"--language" elije el idioma que deseas utilizar cambiando tu idioma actual.

"--reinstallmurrine" se utiliza para re-instalar el motor avanzado Murrine en caso de sobrescribir con una versión actualizada de Murrine desde el Administrador de actualizaciones

"--unholdmurrine" se utiliza si desea recuperar el motor avanzado Murrine.

# =============================================================================================================
# Português:

Instruções:
Essas configurações são apenas para usuários avançados e devem ser usadas apenas se você sabe o que está fazendo ou foi solicitado para isso. Apenas clique duas vezes no ícone e escolha "Executar em um terminal". Use sob seu próprio risco!

==== GUIInstall.sh Switches:  ====

"--errordump" Gera um arquivo de erro para lhe informar sobre seu sistema, ajudando a identificar erros com o script se o mesmo for incapaz de gerar um log de erros por si só. Podem lhe pedir para postar essa informação para solucionar problemas.

"--language" serve para escolher qual idioma você gostaria de usar ao invés do seu idioma atual.

"--reinstallmurrine" é usado para reinstalar a Engine Avançada Murrine caso ela tenha sido sobreescrita por uma nova versão do Gerenciador de atualizações.

"--unholdmurrine" destrava a Engine Avançada Murrine.

