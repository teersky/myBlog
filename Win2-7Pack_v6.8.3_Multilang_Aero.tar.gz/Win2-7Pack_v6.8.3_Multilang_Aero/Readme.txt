# =============================================================================================================
# English:

Thank you for downloading the Win2-7 Pack for Ubuntu! Be sure to read the FAQ carfully on our home page.

Directions:
Please run "GUIInstall.sh" and click "Run In Terminal" to install the pack and run "GUIUninstall.sh" and click "Run In Terminal" to remove the pack. We hope you enjoy it and don't forget to become a fan and vote on our projects home page! Also feel free to donate if you really like it.

Home Page:
http://gnome-look.org/content/show.php/Win2-7+Pack?content=113264

Advanced Users:
You may run the script using a select number of switches. Explore the "switches" folder and read the "Switches Readme.txt" for more details.

#
=============================================================================================================
# Português brasileiro e europeu

Obrigado por instalar o pacote de Win2-7 para Ubuntu! Tenha/Tende certeza que você leu/tu leste com atenção a FAQ na nossa página principal.

Instruções:
Por favor, execute "GUIInstall.sh e clique em "Abrir num terminal" para instalar o pacote ou execute o "GUIUninstall.sh" e clique em "Abrir num terminal" para remover o pacote. Nós esperamos que você/tu desfrute(s) disso e não te esqueça(s) de ser fã e votar na página de nossos projetos! Também sente/sinta livre para doar se você/tu realmente gosta(s) disso. 

Página principal:
http://gnome-look.org/content/show.php/Win2-7+Pack?content=113264

Usuários avançados:
Você/tu deve(s) executar o script usando um número selecionado de comandos. Explore o arquivo dos "comandos" e leia o SWitches Readme.txt" para mais detalhes.

# =============================================================================================================
# French :

Merci d'avoir téléchargé le pack Win2-7 Pack pour Ubuntu ! Prenez le temps de lire attentivement la FAQ (question fréquamment posées) sur notre page d'accueil.

Consignes :
Lancez "GUIInstall.sh" et cliquez sur "Lancer dans un terminal" pour installer le pack ou exécutez "GUIUninstall.sh" puis choisissez "Lancer dans un terminal" pour désinstaller le pack. Nous espérons que vous apprécierez ce pack. Merci de vous inscrire comme Fan du projet et de voter favorablement sur notre page d'accueil. Vous pouvez également faire un don si vous aimez réellement ce projet.

PAge d'accueil :
http://gnome-look.org/content/show.php/Win2-7+Pack?content=113264

Utilisateurs avancés :
Vous pouvez lancer ce script avec un certain nombre de paramètres. Rendez-vous dans le dossier "switches" (paramètres) et lisez attentivement le fichier "Switches Readme.txt" pour plus de détails.

# =============================================================================================================
# Spanish:

¡Gracias por descargar Win2-7 Pack para Ubuntu! Asegúrate de leer las preguntas frecuentes cuidadosamente en nuestra página principal.

Instrucciones:
Por favor, ejecuta "GUIInstall.sh" y haz clic en "Ejecutar en terminal" para instalar el paquete y ejecutar "GUIUninstall.sh" y haga clic en "Ejecutar en terminal" para eliminar el paquete. Esperamos que lo disfrutes y no olvides hacerte fan si te ha gustado así como votar por nuestros proyectos en la página principal También sientete libre de realizar un donativo si te ha gustado este trabajo.

Página de inicio:
http://gnome-look.org/content/show.php/Win2-7+Pack?content=113264

Usuarios avanzados:
Puede ejecutar la secuencia de comandos utilizando un número selecto de interruptores. Explorar los interruptores "carpeta" y leer el "Cambia Readme.txt" para más detalles.

# =============================================================================================================
# Croatian:

Hvala vam što ste skinuli Win2-7 Pack za Ubuntu! Pažljivo pročitajte FAQ na našoj web stranici.

Upute:
Pokrenite "GUIInstall.sh" i kliknite "Pokreni u Terminalu" da instalirate paket ili pokrenite "GUIUninstall.sh" na isti način da uklonite paket. Nadamo se da ćete uživati u njemu. Ne zaboravite postati obožavatelj te glasajte za naš projekt na našoj web stranici! Također, slobodno donirajte ako ga stvarno volite.

Web stranica:
http://gnome-look.org/content/show.php/Win2-7+Pack?content=113264

Napredni korisnici:
Možete pokrenuti skriptu koristeći okidače (switches). Pretražite "switches" mapu i pročitajte "Switches Readme.txt" za više detalja.

